<?php

namespace App\Services;

use App\Models\FacilityRequest;
use App\Models\FormApproval;
use App\Models\MaintenanceRequest;
use App\Models\RepairRequest;
use App\Models\RequisitionSlip;
use App\Models\Role;
use App\Models\User;
use App\Notifications\FormActivity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Notification;

/**
 * Decides WHO gets alerted and WHAT it says. Call it from controllers after saving.
 * It never throws: if the WebSocket server is down the form is still saved (polling still alerts people).
 */
class FormNotifier
{
    /** A new form was filed: maintenance staff + the first approver are alerted. */
    public static function submitted(Model $form): void
    {
        $recipients = self::usersWithRole(Role::maintenanceSlugs());

        // The 3 school forms have a signature chain; tickets do not (yet - Phase 3).
        if (method_exists($form, 'nextApproval')) {
            $recipients = $recipients->merge(self::approversFor($form->nextApproval(), $form));
        }

        self::send($recipients, $form, 'submitted', $form->requester,
            'filed a new '.$form::LABEL);
    }

    /** Someone signed (or rejected) a line. Requester + next approver are alerted. */
    public static function signed(Model $form, User $actor, FormApproval $line, ?string $note = null): void
    {
        $rejected = $line->status === 'rejected';
        $recipients = collect([$form->requester]);

        if (! $rejected) {
            $recipients = $recipients->merge(self::approversFor($form->nextApproval(), $form));

            if ($form->isPresidentApproved()) {   // fully approved
                $recipients = $recipients->merge(self::usersWithRole(Role::maintenanceSlugs()));
                if ($form instanceof FacilityRequest) {
                    $recipients = $recipients->merge(self::usersWithRole(Role::CUSTODIAN));
                }
            }
        }

        $event = $rejected ? 'rejected' : ($form->isPresidentApproved() ? 'approved' : 'signed');
        $verb = $rejected ? 'rejected' : ($event === 'approved' ? 'gave FINAL approval to' : 'signed');

        self::send($recipients, $form, $event, $actor, "{$verb} {$form->reference_no}".($note ? " — {$note}" : ''));
    }

    /** Maintenance tapped [Accept Task] / [Mark Completed] on a ticket (or the old repair form). */
    public static function work(Model $form, User $actor, string $event): void
    {
        $noun = $form instanceof MaintenanceRequest ? 'ticket' : 'repair request';
        $text = $event === 'accepted' ? "accepted your {$noun} and will work on it" : "finished the work on your {$noun}";

        self::send(collect([$form->requester]), $form, $event, $actor, $text);
    }

    /** Phase 9: staff asked the requester for information. Only the requester is alerted. */
    public static function infoRequested(MaintenanceRequest $ticket, User $actor): void
    {
        self::send(collect([$ticket->requester]), $ticket, 'info_requested', $actor, 'needs more information about your ticket');
    }

    /**
     * Phase 12: a ticket was escalated. The authorizers (the President) and the Maintenance Admin are alerted.
     * $actor is null when the tickets:escalate command did it (the alert then says "System"); a person who
     * escalated by hand is not alerted about their own action (see send()).
     */
    public static function escalated(MaintenanceRequest $ticket, ?User $actor = null): void
    {
        $recipients = self::usersWithRole(Role::maintenanceSlugs());

        foreach ((array) config('school.workflow.authorizers', []) as $slug) {
            $recipients = $recipients->merge(self::usersWithRole((string) $slug));
        }

        self::send($recipients, $ticket, 'ticket_escalated', $actor,
            $actor ? 'escalated a ticket to the authorizer' : 'escalated a ticket that passed its target date');
    }

    /**
     * Phase 10: a message in the conversation. When the requester wrote it, the assignee and the maintenance staff
     * are alerted; when someone else wrote it, the requester and the assignee are (never the writer, see send()).
     */
    public static function replied(MaintenanceRequest $ticket, User $actor, bool $internal = false): void
    {
        if ($internal) {   // Phase 11: staff only. The requester is never told, not even that a note exists.
            self::send(
                self::usersWithRole(Role::maintenanceSlugs())->push($ticket->assignee)
                    ->reject(fn (?User $u) => $u === null || (int) $u->id === (int) $ticket->requester_id)
                    ->filter(fn (User $u) => $u->can('viewInternalNotes', $ticket)),
                $ticket, 'ticket_internal_note', $actor, 'added an internal note on a ticket'
            );

            return;
        }

        $recipients = (int) $ticket->requester_id === (int) $actor->id
            ? self::usersWithRole(Role::maintenanceSlugs())->push($ticket->assignee)
            : collect([$ticket->requester, $ticket->assignee]);

        self::send($recipients, $ticket, 'ticket_reply', $actor, 'sent a message on a ticket');
    }

    /**
     * Phase 8: the requester cancelled, reopened or confirmed (closed) their own ticket.
     * The assignee and the maintenance staff are alerted (never the actor, see send()).
     */
    public static function requesterAction(MaintenanceRequest $ticket, User $actor, string $event): void
    {
        $text = match ($event) {
            'cancelled' => 'cancelled their ticket',
            'reopened' => 'reopened their ticket',
            'replied' => 'answered your question on their ticket',
            default => 'confirmed their ticket is resolved',
        };

        self::send(self::usersWithRole(Role::maintenanceSlugs())->push($ticket->assignee), $ticket, $event, $actor, $text);
    }

    // ---------------------------------------------------------------------------------------------

    private static function send(Collection $recipients, Model $form, string $event, ?User $actor, string $text): void
    {
        $recipients = $recipients->filter()->unique('id')
            ->reject(fn (User $u) => $actor !== null && $u->id === $actor->id)   // Phase 12: $actor is null for the system
            ->filter(fn (User $u) => $u->is_active)
            // an alert carries the location and description, so never send it to someone who may not see the ticket
            ->filter(fn (User $u) => ! $form instanceof MaintenanceRequest || $form->isVisibleTo($u));

        if ($recipients->isEmpty()) {
            return;
        }

        $urgent = ($form instanceof MaintenanceRequest || $form instanceof RepairRequest) && $form->isEmergency();

        $actorName = $actor?->name ?? 'System';

        $payload = [
            'event' => $event,
            'form_type' => self::typeOf($form),
            'form_label' => $form::LABEL,
            'form_id' => $form->id,
            'reference_no' => $form->reference_no,
            'requester_name' => $form->requester->name,
            'department' => $form->department?->name,
            'location' => ($form instanceof RepairRequest || $form instanceof MaintenanceRequest) ? $form->location : null,
            'urgent' => $urgent,
            'actor_name' => $actorName,
            'title' => ($urgent ? 'EMERGENCY: ' : '').$actorName.' '.$text,
            'message' => self::summary($form),
        ];

        try {
            Notification::send($recipients, new FormActivity($payload));
        } catch (\Throwable $e) {
            report($e);
        }
    }

    private static function summary(Model $form): string
    {
        return match (true) {
            $form instanceof MaintenanceRequest => "{$form->location} — ".str($form->description)->limit(80),
            $form instanceof RepairRequest => "{$form->location} — ".str($form->job_description)->limit(80),
            $form instanceof FacilityRequest => str($form->purpose)->limit(80),
            $form instanceof RequisitionSlip => 'Needed '.$form->date_needed->format('M j, Y'),
            default => '',
        };
    }

    private static function typeOf(Model $form): string
    {
        return match (true) {
            $form instanceof MaintenanceRequest => 'ticket',
            $form instanceof RepairRequest => 'repair',
            $form instanceof FacilityRequest => 'facility',
            default => 'requisition',
        };
    }

    /** @param string|list<string> $slug one role slug or a list of them */
    private static function usersWithRole(string|array $slug, ?int $departmentId = null): Collection
    {
        return User::query()->where('is_active', true)
            ->whereHas('role', fn ($q) => $q->whereIn('slug', (array) $slug))
            ->when($departmentId, fn ($q) => $q->where('department_id', $departmentId))
            ->get();
    }

    /** Who must sign the given line. Dept. Head = only the head of the requesting department. */
    private static function approversFor(?FormApproval $line, Model $form): Collection
    {
        if (! $line) {
            return collect();
        }

        return self::usersWithRole($line->role_slug, $line->role_slug === Role::DEPARTMENT_HEAD ? $form->department_id : null);
    }
}
