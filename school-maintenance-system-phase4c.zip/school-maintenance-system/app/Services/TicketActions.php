<?php

namespace App\Services;

use App\Enums\TicketStatus;
use App\Models\MaintenanceRequest;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Gate;

/**
 * Which actions the ticket detail page offers THIS user right now.
 *
 * An action is listed only when (a) the ticket's status allows it (TicketStatus::allowedNext(), or the
 * status rules in TicketWorkflow for actions that keep the status) AND (b) the user has the capability
 * (TicketPolicy). The controllers re-check both, so hiding a button is never the only protection.
 */
class TicketActions
{
    public const SEND_FOR_AUTHORIZATION = 'send_for_authorization';

    public const APPROVE = 'approve';

    public const DISAPPROVE = 'disapprove';

    public const ASSIGN = 'assign';

    public const REASSIGN = 'reassign';

    public const FLAG_EMERGENCY = 'flag_emergency';

    public const CLEAR_EMERGENCY = 'clear_emergency';

    public const ADD_NOTE = 'add_note';

    // Phase 8: the requester's own actions
    public const CANCEL = 'cancel';

    public const CONFIRM_RESOLVED = 'confirm_resolved';

    public const REOPEN = 'reopen';

    // Phase 9: ask for information / answer
    public const REQUEST_INFO = 'request_info';

    public const RESPOND_INFO = 'respond_info';

    // Phase 12: hand the ticket up to the authorizer
    public const ESCALATE = 'escalate';

    // Staff rules: a Maintenance Staff member claims an unassigned ticket and transfers their own (with a reason)
    public const CLAIM = 'claim';

    public const TRANSFER = 'transfer';

    /** @return list<string> */
    public static function for(MaintenanceRequest $ticket, User $user): array
    {
        $status = $ticket->status;

        $can = fn (string $ability) => Gate::forUser($user)->allows($ability, $ticket);

        if ($status->isTerminal()) {
            // Closed / Disapproved / Cancelled: nothing more can happen, except that the requester may still
            // REOPEN a Closed ticket inside the window (Phase 8).
            return $status === TicketStatus::Closed && $can('reopen') && TicketWorkflow::reopenBlocker($ticket, $user) === null
                ? [self::REOPEN]
                : [];
        }

        $actions = [];

        // Only a Submitted ticket is sent for authorization (Phase 7: Waiting for User / Escalated may also move to Pending Authorization, but only through their own actions)
        if ($status === TicketStatus::Submitted && $can('sendForAuthorization')) {
            $actions[] = self::SEND_FOR_AUTHORIZATION;
        }

        // Approve / Disapprove: from Pending Authorization, and from Submitted only when the config allows it.
        $authorizable = in_array($status->value, MaintenanceRequest::authorizableStatusValues(), true);

        if ($authorizable && $status->canTransitionTo(TicketStatus::Approved) && $can('authorize')) {
            $actions[] = self::APPROVE;
        }
        if ($authorizable && $status->canTransitionTo(TicketStatus::Disapproved) && $can('disapprove')) {
            $actions[] = self::DISAPPROVE;
        }

        if ($user->isStaffOnly()) {
            // Staff do not get the Assign / Reassign form: they claim an unassigned ticket or transfer their own.
            if (in_array($status, TicketWorkflow::assignableStatuses(), true)) {
                if ($ticket->assigned_to === null && $can('claim')) {
                    $actions[] = self::CLAIM;
                } elseif ($ticket->assigned_to !== null && (int) $ticket->assigned_to === (int) $user->id && $can('transfer')) {
                    $actions[] = self::TRANSFER;
                }
            }
        } elseif ($can('assign')) {
            if ($status === TicketStatus::Approved) {
                $actions[] = self::ASSIGN;
            } elseif (in_array($status, [TicketStatus::Assigned, TicketStatus::InProgress, TicketStatus::Reopened], true)) {
                $actions[] = self::REASSIGN;
            }
        }

        if (! $ticket->is_emergency && $can('flagEmergency')) {
            $actions[] = self::FLAG_EMERGENCY;
        }
        if ($ticket->is_emergency && $can('clearEmergency')) {
            $actions[] = self::CLEAR_EMERGENCY;
        }

        // Phase 9: staff ask a question (not while already waiting); the requester answers it
        if ($status !== TicketStatus::WaitingForUser && $status->canTransitionTo(TicketStatus::WaitingForUser) && $can('requestInfo')) {
            $actions[] = self::REQUEST_INFO;
        }
        if ($status === TicketStatus::WaitingForUser && $can('respondToInfo')) {
            $actions[] = self::RESPOND_INFO;
        }

        // Phase 12: escalate (not while waiting for the requester, not when already escalated)
        if (TicketWorkflow::escalateBlocker($ticket) === null && $can('escalate')) {
            $actions[] = self::ESCALATE;
        }

        // Phase 8: the requester's own actions (policy = who, TicketWorkflow = which status / window)
        if ($status === TicketStatus::WorkCompleted && $can('confirmResolved')) {
            $actions[] = self::CONFIRM_RESOLVED;
        }
        if ($can('reopen') && TicketWorkflow::reopenBlocker($ticket, $user) === null) {
            $actions[] = self::REOPEN;
        }
        if ($can('cancel') && TicketWorkflow::cancelBlocker($ticket, $user) === null) {
            $actions[] = self::CANCEL;
        }

        if ($can('addNote')) {
            $actions[] = self::ADD_NOTE;
        }

        return $actions;
    }

    /**
     * Active maintenance staff with how many open (not yet completed) tickets each one holds,
     * for the Assign / Reassign dropdown.
     *
     * @return Collection<int, User>
     */
    public static function assignableStaff(): Collection
    {
        return User::query()
            ->where('is_active', true)
            ->whereHas('role', fn ($q) => $q->whereIn('slug', Role::maintenanceSlugs()))
            ->withCount(['assignedRequests as open_tickets_count' => fn ($q) => $q->pending()])
            ->orderBy('name')
            ->get();
    }

    /**
     * Phase 4C: the Assign / Reassign / Transfer dropdown for THIS actor on THIS ticket.
     *  - Department Staff (staff-only): only colleagues in their own department (they cannot transfer
     *    cross-department, so other departments are not offered).
     *  - Head / Maintenance Admin / System Administrator (cross_department_transfer): everyone, so a
     *    cross-department transfer can be picked; the workflow still requires a reason for it.
     *  - No actor (or a global actor): everyone (the old behaviour).
     * No department is hardcoded: the filter uses the actor's users.department_id.
     *
     * @return Collection<int, User>
     */
    public static function assignableStaffFor(?MaintenanceRequest $ticket, ?User $actor = null): Collection
    {
        if ($actor === null || $actor->isGlobalRole() || $actor->canTransferCrossDepartment()) {
            return self::assignableStaff();
        }

        if ($actor->isStaffOnly()) {
            $departmentId = $actor->scopedDepartmentId();

            if ($departmentId === null) {
                return collect();
            }

            return User::query()
                ->where('is_active', true)
                ->where('department_id', $departmentId)
                ->whereHas('role', fn ($q) => $q->whereIn('slug', Role::maintenanceSlugs()))
                ->withCount(['assignedRequests as open_tickets_count' => fn ($q) => $q->pending()])
                ->orderBy('name')
                ->get();
        }

        return self::assignableStaff();
    }
}
