# LCCT Maintenance Ticketing System — Phase 4C build

This zip contains the FULL working tree of branch
`arena/922dbfb5-school-maintenance-system`, including the uncommitted Phase 4C
changes (department-scoped roles, assignment rules, matrix doc, and the new
role x department test). It is NOT a git repository; use it to run the app or
to copy the changed files into your own clone.

## Requirements

- PHP 8.3+ with the usual Laravel extensions (pdo_sqlite / pdo_mysql, mbstring,
  openssl, fileinfo, gd/intl as needed)
- Composer 2
- Node.js 20+ and npm (only for the Vite assets)
- MySQL 8 (default `.env.example`) OR nothing at all for tests (phpunit uses
  in-memory SQLite)

## 1. Extract

```bash
unzip school-maintenance-system-phase4c.zip
cd school-maintenance-system
```

## 2. Install and run

```bash
composer install
cp .env.example .env
php artisan key:generate
```

Edit `.env` and set `DB_*` for your MySQL database (create an empty database
called `school_maintenance` first), then:

```bash
php artisan migrate --seed
npm install --ignore-scripts
npm run build
php artisan serve
```

Open http://localhost:8000  (seeded login: sysadmin@lcctanauan.edu.ph / password)

If you just want a quick look with SQLite instead of MySQL, set in `.env`:

```
DB_CONNECTION=sqlite
```

and create the file first: `touch database/database.sqlite` (on Windows:
`type nul > database\database.sqlite`). Then run `php artisan migrate --seed`.

## 3. Run the Phase 4C tests (no MySQL needed — phpunit.xml uses SQLite in memory)

```bash
php artisan test --filter=DepartmentAssignmentRulesTest
php artisan test --filter="TicketViewVisibilityTest|DepartmentScopedRolesTest|StaffTicketRulesTest|StaffHeadRolesTest"
php artisan test
```

These tests could NOT be executed in the sandbox I built this zip in (no PHP
runtime there), so please run them locally and send me any failures.

## 4. Optional: static visual preview (no PHP needed)

```bash
cd preview
node server.js
```

Then open http://localhost:5173 — switch roles to see the visibility/404 and
claim/assign/transfer rules. It is a static UI demo built from the real CSS and
images, NOT the Laravel backend.

## What changed in this build

- `config/permissions.php` — `cross_department_transfer` capability for
  system_admin / maintenance_admin / head only
- `app/Models/Role.php`, `app/Models/User.php` — `crossDepartmentSlugs()`,
  `canTransferCrossDepartment()`
- `app/Policies/TicketPolicy.php` — claim limited to own department; assign /
  transfer comments + `inOwnDepartment()`
- `app/Services/TicketWorkflow.php` — `isCrossDepartmentAssignment()`; scoped
  actor, staff claim/transfer, and cross-department (capability + reason)
  enforcement in `assign()`; own-department checks in `claim()` / `transfer()`
- `app/Services/TicketActions.php` — `assignableStaffFor()` scoped dropdown
- `app/Http/Controllers/TicketController.php`, `ReportController.php`,
  `TicketActionController.php` — scoped dropdowns; cross-department first
  assignment requires a reason
- `routes/web.php` — Phase 4C annotations on the work queue routes
- `docs/ROLE_PERMISSION_MATRIX.md` (new), `docs/ROLES_AND_WORKFLOW.md`,
  `docs/OPEN_QUESTIONS.md` (#103-106)
- `tests/Feature/DepartmentAssignmentRulesTest.php` (new) — 11 role x
  department tests, including Finance staff cannot see a Registrar ticket
