# Static visual preview

Run `node server.js` here and open http://localhost:5173.
This uses the real CSS/images from `public/` but is a static UI demo, not the
Laravel application. A role switcher demonstrates the Phase 4C rules.
